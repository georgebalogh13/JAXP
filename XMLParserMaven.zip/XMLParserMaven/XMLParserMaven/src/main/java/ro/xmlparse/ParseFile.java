package ro.xmlparse;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ParseFile {
    public static void main(String[] args) {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

        try {
            documentBuilderFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

            Document document = documentBuilder.parse(new File("/Users/naebara/IdeaProjects/XMLParserMaven/src/file.xml"));
            document.getDocumentElement().normalize();

            NodeList books = document.getElementsByTagName("book");

            for (int temp = 0; temp < books.getLength(); temp++) {

                Node book = books.item(temp);

                if (book.getNodeType() == Node.ELEMENT_NODE) {

                    Element bookElement = (Element) book;

                    String name = bookElement.getElementsByTagName("name").item(0).getTextContent();
                    String title = bookElement.getElementsByTagName("title").item(0).getTextContent();
                    String price = bookElement.getElementsByTagName("price").item(0).getTextContent();
                    String publish = bookElement.getElementsByTagName("publish_date").item(0).getTextContent();
                    String detail = bookElement.getElementsByTagName("detail").item(0).getTextContent();

                    double priceValue = Double.parseDouble(price);
                    int year = Integer.parseInt(publish.substring(0, 4));
                    if(year >= 2005 && priceValue > 10){
                        System.out.println("--- BOOK ---");
                        System.out.println("Author : " + name);
                        System.out.println("Title : " + title);
                        System.out.println("Price : " + price);
                        System.out.println("Publish Date : " + publish);
                        System.out.println("Details : " + detail);
                    }




                }
            }

        } catch (SAXException | IOException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }
}
